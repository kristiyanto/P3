source("https://bioconductor.org/biocLite.R")
biocLite("mzID")
biocLite("MSnbase")
install.packages("stringr")